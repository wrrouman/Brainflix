import "./NextVideos.scss";
import videosData from "../../data/videos.json";

// props.updateVideoId

function NextVideos(props) {
  console.log(videosData);

  const renderVideoLink = (videoData) => {
    return (
      <li key={videoData.id} onClick={() => {props.updateVideoId(videoData.id)}}>
        <img src={videoData.image} />
        <div>
          <h3>{videoData.title}</h3>
          <h2>{videoData.channel}</h2>
        </div>
      </li>
    );
  };

  return (
    <>
      <h3>Next Videos</h3>
      <ul>{videosData.map((videoData) => renderVideoLink(videoData))}</ul>
    </>
  );
}

export default NextVideos;
