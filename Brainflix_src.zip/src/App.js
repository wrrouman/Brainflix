import "./App.css";
import Header from "./components/Header/Header.js";
import VideoPage from "./components/VideoPage/VideoPage";
function App() {
  return (
    <>
      <Header />
      <VideoPage />
    </>
  );
}

export default App;
